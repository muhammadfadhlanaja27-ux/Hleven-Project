<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RoomType extends Model
{
    use HasFactory, SoftDeletes;

    protected $attributes = [
        'bed_count' => 1,
        'breakfast' => false,
        'smoking_area' => false,
        'is_refundable' => true,
        'is_active' => true,
    ];

    protected $fillable = [
        'hotel_id', 'bed_type_id', 'bed_count', 'room_type_category_id', 'name', 'type', 'bed', 'description',
        'weekday_price', 'weekend_price', 'stock', 'capacity_adult', 'capacity_child', 'breakfast',
        'smoking_area', 'is_refundable', 'policies',
    ];

    protected $casts = [
        'bed_count' => 'integer',
    ];

    public function hotel()
    {
        return $this->belongsTo(Hotel::class, 'hotel_id');
    }

    public function bedType()
    {
        return $this->belongsTo(BedType::class, 'bed_type_id');
    }

    public function category()
    {
        return $this->belongsTo(RoomTypeCategory::class, 'room_type_category_id');
    }

    public function photos()
    {
        return $this->hasMany(RoomPhoto::class, 'room_type_id');
    }

    public function facilities()
    {
        return $this->belongsToMany(Facility::class, 'room_facilities', 'room_type_id', 'facility_id');
    }

    public function availabilities()
    {
        return $this->hasMany(RoomAvailability::class, 'room_type_id');
    }

    public function priceHistories()
    {
        return $this->hasMany(RoomPriceHistory::class, 'room_type_id');
    }

    public function bookingRooms()
    {
        return $this->hasMany(BookingRoom::class, 'room_type_id');
    }
}
