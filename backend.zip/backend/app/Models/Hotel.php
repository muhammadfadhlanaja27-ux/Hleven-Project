<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Hotel extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'admin_id', 'city_id', 'name', 'slug', 'description', 'address',
        'average_rating', 'total_review', 'latitude', 'longitude', 'status',
        'star_rating', 'star_verified_by', 'star_verified_at', 'star_verified_reason',
        'property_type', 'year_built',
        'policies', 'tax_rate', 'logo', 'allow_pay_at_hotel',
        'bank_name', 'bank_account_number', 'bank_account_name',
    ];

    protected $casts = [
        'star_rating' => 'integer',
        'year_built' => 'integer',
        'star_verified_at' => 'datetime',
        'tax_rate' => 'decimal:2',
        'allow_pay_at_hotel' => 'boolean',
    ];

    protected $appends = ['starting_price', 'thumbnail', 'reviews_avg_rating', 'reviews_count'];

    public function getStartingPriceAttribute()
    {
        if ($this->relationLoaded('roomTypes')) {
            return $this->roomTypes->min('weekday_price') ?? 0;
        }

        return $this->roomTypes()->min('weekday_price') ?? 0;
    }

    public function getThumbnailAttribute()
    {
        if ($this->relationLoaded('photos')) {
            $thumbnailPhoto = $this->photos->firstWhere('is_thumbnail', true) ?? $this->photos->first();

            return $thumbnailPhoto ? $thumbnailPhoto->photo : null;
        }
        $thumbnailPhoto = $this->photos()->where('is_thumbnail', true)->first() ?? $this->photos()->first();

        return $thumbnailPhoto ? $thumbnailPhoto->photo : null;
    }

    public function getPhoneAttribute()
    {
        if ($this->relationLoaded('admin')) {
            return $this->admin?->phone;
        }

        return $this->admin()->value('phone');
    }

    public function getEmailAttribute()
    {
        if ($this->relationLoaded('admin')) {
            return $this->admin?->email;
        }

        return $this->admin()->value('email');
    }

    public function getReviewsAvgRatingAttribute()
    {
        return (float) ($this->attributes['reviews_avg_rating'] ?? $this->reviews()->avg('rating') ?? 0);
    }

    public function getReviewsCountAttribute()
    {
        return (int) ($this->attributes['reviews_count'] ?? $this->reviews()->count());
    }

    public function admin()
    {
        return $this->belongsTo(User::class, 'admin_id');
    }

    public function starVerifier()
    {
        return $this->belongsTo(User::class, 'star_verified_by');
    }

    public function city()
    {
        return $this->belongsTo(City::class, 'city_id');
    }

    public function photos()
    {
        return $this->hasMany(HotelPhoto::class, 'hotel_id');
    }

    public function facilities()
    {
        return $this->belongsToMany(Facility::class, 'hotel_facilities', 'hotel_id', 'facility_id');
    }

    public function bedTypes()
    {
        return $this->hasMany(BedType::class);
    }

    public function roomTypes()
    {
        return $this->hasMany(RoomType::class, 'hotel_id');
    }

    public function bookings()
    {
        return $this->hasMany(Booking::class, 'hotel_id');
    }

    public function payoutDestinations()
    {
        return $this->hasMany(HotelPayoutDestination::class);
    }

    public function withdrawals()
    {
        return $this->hasMany(HotelWithdrawal::class);
    }

    public function walletLedgerEntries()
    {
        return $this->hasMany(WalletLedgerEntry::class);
    }

    public function reviews()
    {
        return $this->hasMany(Review::class, 'hotel_id');
    }

    public function warnings()
    {
        return $this->hasMany(Warning::class, 'hotel_id');
    }

    public function appeals()
    {
        return $this->hasMany(Appeal::class, 'hotel_id');
    }

    public function payouts()
    {
        return $this->hasMany(Payout::class, 'hotel_id');
    }
}
