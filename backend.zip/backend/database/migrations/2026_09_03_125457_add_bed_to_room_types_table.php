<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (! Schema::hasColumn('room_types', 'bed')) {
            Schema::table('room_types', function (Blueprint $table) {
                $table->string('bed', 100)->nullable()->after('type');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasColumn('room_types', 'bed')) {
            Schema::table('room_types', function (Blueprint $table) {
                $table->dropColumn('bed');
            });
        }
    }
};
