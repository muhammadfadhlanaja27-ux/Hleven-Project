import { useState, useEffect } from "react";
import { cachedGet, invalidateCache } from "../services/apiCache";
import api from "../services/api";
import toast from "react-hot-toast";

const ReviewSection = ({ hotelId, roomTypes = [], onReviewSubmitted }) => {
  const [reviews, setReviews] = useState([]);
  const [stats, setStats] = useState({ average_rating: 0, total_reviews: 0 });
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState("");
  const [rating, setRating] = useState("all");
  const [roomTypeId, setRoomTypeId] = useState("all");

  // Form
  const [eligibleBookings, setEligibleBookings] = useState([]);
  const [form, setForm] = useState({ booking_id: "", rating: 5, comment: "" });
  const [submitting, setSubmitting] = useState(false);
  const isAuthenticated = !!localStorage.getItem("token");

  const fetchReviews = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/hotels/${hotelId}/reviews`, {
        params: { page, limit: 10, search, rating, roomTypeId },
      });
      setReviews(res.data.data.data || []);
      setTotalPages(res.data.data.last_page || 1);
      const newStats = res.data.stats || { average_rating: 0, total_reviews: 0 };
      setStats(newStats);
      return newStats;
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
    return null;
  };

  const fetchEligibleBookings = async () => {
    if (!isAuthenticated) return;
    try {
      const res = await api.get(`/hotels/${hotelId}/eligible-bookings`, {
        skipAuthRedirect: true,
      });
      setEligibleBookings(res.data.data || []);
    } catch (err) {
      // Catch 403 Forbidden or any other error so it doesn't crash the whole page
      console.warn("ReviewSection: User not eligible or not logged in properly", err.response?.status);
      setEligibleBookings([]);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, [hotelId, page, search, rating, roomTypeId]);

  useEffect(() => {
    fetchEligibleBookings();
  }, [hotelId, isAuthenticated]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.booking_id) {
      toast.error("Please select the booking you want to review.");
      return;
    }
    setSubmitting(true);
    try {
      await api.post(`/hotels/${hotelId}/reviews`, form);
      toast.success("Review submitted successfully!");
      setForm({ booking_id: "", rating: 5, comment: "" });
      fetchEligibleBookings();
      const newStats = await fetchReviews();
      // Invalidate hotel list cache agar landing page mendapat rating terbaru
      invalidateCache("/hotels");
      // Notify parent (HotelDetail) agar bintang header ter-update dengan rating baru
      if (onReviewSubmitted && newStats) onReviewSubmitted(newStats);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to submit review");
    }
    setSubmitting(false);
  };

  return (
    <section className="mt-16 pt-10 border-t border-[#DCCFC0]/40">
      <div className="flex flex-col md:flex-row justify-between mb-8 gap-4">
        <div>
          <h2 className="font-headline-lg text-2xl md:text-3xl font-bold text-[#778873] mb-1">
            Guest Reviews
          </h2>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#D48C45]" style={{ fontVariationSettings: "'FILL' 1" }}>star</span>
            <span className="font-bold text-lg">{Number(stats.average_rating).toFixed(1)}</span>
            <span className="text-sm text-[#444842]">({stats.total_reviews} Reviews)</span>
          </div>
        </div>
      </div>

      {isAuthenticated && eligibleBookings.length > 0 && (
        <div className="bg-[#DCCFC0]/20 border border-[#DCCFC0]/60 rounded-2xl p-5 mb-8">
          <h3 className="font-label-md text-sm font-bold text-[#778873] uppercase mb-4">Write Your Review</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <select
              value={form.booking_id}
              onChange={(e) => setForm({ ...form, booking_id: e.target.value })}
              className="w-full border border-[#DCCFC0] rounded-xl p-3 bg-[#FDF6ED] text-sm"
              required
            >
              <option value="">-- Select Booking (Completed) --</option>
              {eligibleBookings.map((b) => (
                <option key={b.id} value={b.id}>
                  Booking #{b.booking_code} - {b.booking_rooms?.map(r => r.room_type?.name).join(', ')}
                </option>
              ))}
            </select>
            
            <div className="flex gap-2 items-center">
              <label className="text-sm font-semibold">Rating:</label>
              {[1, 2, 3, 4, 5].map(star => (
                <span
                  key={star}
                  className="material-symbols-outlined cursor-pointer text-xl"
                  style={{ color: star <= form.rating ? '#D48C45' : '#DCCFC0' }}
                  onClick={() => setForm({ ...form, rating: star })}
                >
                  star
                </span>
              ))}
            </div>

            <textarea
              placeholder="Share your stay experience..."
              value={form.comment}
              onChange={(e) => setForm({ ...form, comment: e.target.value })}
              className="w-full border border-[#DCCFC0] rounded-xl p-3 bg-[#FDF6ED] text-sm h-24"
              required
            />
            <button type="submit" disabled={submitting} className="bg-[#778873] text-white px-6 py-2 rounded-xl text-sm font-semibold hover:bg-[#50604d]">
              {submitting ? 'Submitting...' : 'Submit Review'}
            </button>
          </form>
        </div>
      )}

      {/* Filter Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
        <input
          type="text"
          placeholder="Search reviews..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border border-[#DCCFC0] rounded-xl p-3 bg-[#FDF6ED] text-sm w-full"
        />
        <select value={rating} onChange={(e) => setRating(e.target.value)} className="border border-[#DCCFC0] rounded-xl p-3 bg-[#FDF6ED] text-sm w-full">
          <option value="all">All Stars</option>
          {[5, 4, 3, 2, 1].map(r => <option key={r} value={r}>{r} Stars</option>)}
        </select>
        <select value={roomTypeId} onChange={(e) => setRoomTypeId(e.target.value)} className="border border-[#DCCFC0] rounded-xl p-3 bg-[#FDF6ED] text-sm w-full">
          <option value="all">All Room Types</option>
          {roomTypes.map(rt => <option key={rt.id} value={rt.id}>{rt.name}</option>)}
        </select>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {loading ? <p className="text-sm">Loading...</p> : reviews.length === 0 ? <p className="text-sm text-gray-500">No reviews yet.</p> : reviews.map((review) => {
          const roomNames = review.booking?.booking_rooms?.map(r => r.room_type?.name).join(', ') || 'Room';
          const nights = review.booking?.total_night || 0;
          const guests = review.booking?.guests?.length || 0;
          
          return (
            <div key={review.id} className="bg-[#faf3ea] rounded-2xl p-5 border border-[#DCCFC0]/40">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-bold text-[#1e1b16]">{review.user?.name || 'User'}</h4>
                  <p className="text-xs text-[#444842]">{new Date(review.created_at).toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                </div>
                <div className="flex text-[#D48C45]">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className="material-symbols-outlined text-sm" style={{ fontVariationSettings: i < review.rating ? "'FILL' 1" : "'FILL' 0" }}>star</span>
                  ))}
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="bg-[#DCCFC0]/30 text-[#444842] px-2 py-1 rounded text-[10px] font-semibold">{roomNames}</span>
                <span className="bg-[#DCCFC0]/30 text-[#444842] px-2 py-1 rounded text-[10px] font-semibold">{nights} Nights</span>
                <span className="bg-[#DCCFC0]/30 text-[#444842] px-2 py-1 rounded text-[10px] font-semibold">{guests} Guests</span>
              </div>
              <p className="text-sm text-[#1e1b16]">{review.comment}</p>
              {review.reply && (
                <div className="mt-4 bg-[#E4EBE0]/50 rounded-xl p-4 border border-[#c4c8be]/40">
                  <p className="text-xs font-bold text-[#4A5D43] mb-1">Hotel Reply:</p>
                  <p className="text-sm text-[#2D312C]">{review.reply}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-6">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1 border border-[#778873] rounded text-sm disabled:opacity-50">‹</button>
          <span className="px-3 py-1 text-sm font-bold">{page} / {totalPages}</span>
          <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-3 py-1 border border-[#778873] rounded text-sm disabled:opacity-50">›</button>
        </div>
      )}
    </section>
  );
};

export default ReviewSection;
