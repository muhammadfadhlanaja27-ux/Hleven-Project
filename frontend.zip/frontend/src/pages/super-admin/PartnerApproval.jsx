import React, { useState, useEffect } from "react";
import api from "../../services/api";
import { cachedGet, getCachedData, getCacheKey, invalidateCache } from "../../services/apiCache";
import { toast } from "react-hot-toast";
import ConfirmDialog from "../../components/ui/ConfirmDialog";
import { getStorageUrl } from "../../services/imageUrl";

const openPartnerDocument = async (appId, docId, fallbackUrl) => {
  try {
    const res = await api.get(`/super-admin/partners/${appId}/documents/${docId}`, { responseType: "blob" });
    const mime = res.headers?.["content-type"] || "application/octet-stream";
    const url = URL.createObjectURL(new Blob([res.data], { type: mime }));
    window.open(url, "_blank", "noopener,noreferrer");
  } catch (err) {
    if (fallbackUrl) {
      window.open(fallbackUrl, "_blank", "noopener,noreferrer");
      return;
    }
    toast.error(err.response?.data?.message || "Failed to open document.");
  }
};

const getDocLabel = (type) => {
  const map = {
    ktp: "KTP / Owner ID",
    legalitas: "Hotel Legality Document",
    pendukung: "Supporting Document",
  };
  return map[type] || `Document (${type || "Other"})`;
};

const getDocIcon = (type) => {
  const t = String(type || "").toLowerCase();
  if (t === "ktp") return "badge";
  if (t === "legalitas" || t === "legal") return "gavel";
  return "description";
};

const PartnerApproval = () => {
  const initialKey = getCacheKey("/super-admin/partners");
  const cachedInitialPartners = getCachedData(initialKey)?.data || getCachedData(initialKey) || null;

  const [partners, setPartners] = useState(Array.isArray(cachedInitialPartners) ? cachedInitialPartners : []);
  const [loading, setLoading] = useState(!cachedInitialPartners);
  const [error, setError] = useState(false);

  // Search & Filter
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Selected partner for review modal
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);

  // Rejection modal
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [rejectPartnerId, setRejectPartnerId] = useState(null);
  const [rejectLoading, setRejectLoading] = useState(false);

  const [pendingApprove, setPendingApprove] = useState(null);
  const [isApproving, setIsApproving] = useState(false);
  const [approveStar, setApproveStar] = useState("");
  const [approveStarReason, setApproveStarReason] = useState("");

  // Fetch partners
  const fetchPartners = async (forceRefresh = false) => {
    const key = getCacheKey("/super-admin/partners");
    const cached = getCachedData(key);

    if (!forceRefresh && cached) {
      const data = cached.data || cached || [];
      setPartners(Array.isArray(data) ? data : []);
      setLoading(false);
    } else if (partners.length === 0 || forceRefresh) {
      if (partners.length === 0) setLoading(true);
    }

    try {
      setError(false);
      const response = await cachedGet("/super-admin/partners", {}, forceRefresh);
      const data = response.data?.data || response.data || [];
      setPartners(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Failed to fetch application data:", err);
      if (partners.length === 0) setError(true);
      toast.error("Failed to load partner application data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPartners(false);
  }, []);

  const handleApprove = (id) => {
    const p = partners.find((x) => x.id === id);
    setApproveStar(p?.requested_star_rating ? String(p.requested_star_rating) : "");
    setApproveStarReason("");
    setPendingApprove(id);
  };

  const performApprove = async () => {
    if (!pendingApprove) return;
    const id = pendingApprove;
    const selected = partners.find((x) => x.id === id);
    const starToSend = approveStar ? Number(approveStar) : (selected?.requested_star_rating || null);
    setIsApproving(true);
    try {
      await api.patch(`/super-admin/partners/${id}/approve`, { star_rating: starToSend, star_verified_reason: approveStarReason || null });
      invalidateCache("/super-admin/partners");
      invalidateCache("/super-admin/dashboard");
      toast.success("Partner application successfully approved!");
      if (selectedPartner && selectedPartner.id === id) {
        setSelectedPartner((prev) => ({ ...prev, status: "Approved" }));
      }
      setPendingApprove(null);
      fetchPartners(true);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to approve application.");
    } finally {
      setIsApproving(false);
    }
  };

  const openRejectModal = (id) => {
    setRejectPartnerId(id);
    setRejectReason("");
    setIsRejectModalOpen(true);
  };

  const handleConfirmReject = async (e) => {
    e.preventDefault();
    if (!rejectReason.trim()) {
      toast.error("Rejection reason is required!");
      return;
    }

    setRejectLoading(true);
    try {
      await api.patch(`/super-admin/partners/${rejectPartnerId}/reject`, {
        reason: rejectReason,
      });
      invalidateCache("/super-admin/partners");
      invalidateCache("/super-admin/dashboard");
      toast.success("Partner application rejected.");
      setIsRejectModalOpen(false);
      if (selectedPartner && selectedPartner.id === rejectPartnerId) {
        setSelectedPartner((prev) => ({ ...prev, status: "Rejected" }));
      }
      fetchPartners(true);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to reject application.");
    } finally {
      setRejectLoading(false);
    }
  };

  // Helper formatting initials
  const getInitials = (name) => {
    if (!name) return "PT";
    const parts = name.trim().split(" ");
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  // Filtered partners
  const filteredPartners = partners.filter((partner) => {
    const applicantName = (partner.applicant_name || partner.user?.name || "").toLowerCase();
    const hotelName = (partner.hotel_name || "").toLowerCase();
    const email = (partner.email || partner.user?.email || "").toLowerCase();
    const q = search.toLowerCase();

    const matchesSearch =
      !q ||
      applicantName.includes(q) ||
      hotelName.includes(q) ||
      email.includes(q);

    const matchesStatus =
      !statusFilter ||
      (partner.status || "").toLowerCase() === statusFilter.toLowerCase();

    return matchesSearch && matchesStatus;
  });

  // Pagination helper
  const totalItems = filteredPartners.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
  const paginatedPartners = filteredPartners.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="w-full max-w-7xl mx-auto space-y-8 font-hanken">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h2 className="font-newsreader text-[32px] font-semibold text-[#4f604f] tracking-[-0.02em] leading-tight font-['Newsreader',serif]">
              Partner Approval
            </h2>
          <p className="font-hanken text-[14px] text-[#747872] mt-1">
            Review and manage new hotel partner applications and compliance documents.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Search Input */}
          <div className="relative flex-1 md:w-64">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[#747872] text-[20px] pointer-events-none">
              search
            </span>
            <input
              type="text"
              placeholder="Search applications..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-[#E5E0D8] rounded-lg font-hanken text-[14px] text-[#191c1b] placeholder-[#747872] focus:outline-none focus:border-[#768875] focus:ring-2 focus:ring-[#768875]/20 transition-all shadow-sm"
            />
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3.5 py-2 bg-white border border-[#E5E0D8] rounded-lg font-hanken text-[14px] text-[#191c1b] focus:outline-none focus:border-[#768875] focus:ring-2 focus:ring-[#768875]/20 transition-all shadow-sm cursor-pointer"
          >
            <option value="">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>

          {/* Refresh Button */}
          <button
            onClick={() => fetchPartners(true)}
            title="Refresh Data"
            className="flex items-center gap-1.5 px-3 py-2 border border-[#E5E0D8] rounded-lg bg-white text-[#434842] hover:bg-[#F9F6F1] transition-all font-hanken text-[13px] font-semibold shadow-sm"
          >
            <span className="material-symbols-outlined text-[18px]">refresh</span>
            <span className="hidden sm:inline">Refresh</span>
          </button>
        </div>
      </div>

      {/* Main Data Table Card */}
      <div className="bg-white rounded-xl shadow-[0_4px_20px_rgba(47,50,49,0.06)] overflow-hidden border border-[#E5E0D8]">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-4">
            <div className="w-10 h-10 border-4 border-[#E5E0D8] border-t-[#768875] rounded-full animate-spin"></div>
            <p className="font-hanken text-[14px] text-[#747872]">Loading partner applications...</p>
          </div>
        ) : error ? (
          <div className="p-12 text-center space-y-3 font-hanken">
            <p className="text-[#ba1a1a] font-medium text-[15px]">
              An error occurred while loading application data.
            </p>
            <button
              onClick={fetchPartners}
              className="px-4 py-2 bg-[#768875] text-white rounded-lg text-[13px] font-semibold hover:opacity-90 transition-opacity"
            >
              Try Again
            </button>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[800px]">
                <thead>
                  <tr className="bg-[#F9F6F1] border-b border-[#E5E0D8]">
                    <th className="py-4 px-6 font-hanken text-[12px] font-semibold text-[#434842] uppercase tracking-[0.05em]">
                      Owner Name
                    </th>
                    <th className="py-4 px-6 font-hanken text-[12px] font-semibold text-[#434842] uppercase tracking-[0.05em]">
                      Hotel Name
                    </th>
                    <th className="py-4 px-6 font-hanken text-[12px] font-semibold text-[#434842] uppercase tracking-[0.05em]">
                      Date Applied
                    </th>
                    <th className="py-4 px-6 font-hanken text-[12px] font-semibold text-[#434842] uppercase tracking-[0.05em]">
                      Status
                    </th>
                    <th className="py-4 px-6 font-hanken text-[12px] font-semibold text-[#434842] uppercase tracking-[0.05em] text-right">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E0D8] font-hanken text-[13.5px]">
                  {paginatedPartners.length > 0 ? (
                    paginatedPartners.map((row) => {
                      const status = row.status || "Pending";
                      const isPending = status.toLowerCase() === "pending";
                      const isApproved = status.toLowerCase() === "approved";
                      const isRejected = status.toLowerCase() === "rejected";

                      const ownerName = row.applicant_name || row.user?.name || "Partner Owner";
                      const ownerEmail = row.email || row.user?.email || "";
                      const hotelName = row.hotel_name || "New Hotel Property";

                      return (
                        <tr
                          key={row.id}
                          className="hover:bg-[#F9F6F1]/50 transition-colors group cursor-pointer"
                          onClick={() => {
                            setSelectedPartner(row);
                            setIsReviewModalOpen(true);
                          }}
                        >
                          {/* Owner Name */}
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-3.5">
                              <div className="w-9 h-9 rounded-full bg-[#edeeec] text-[#434842] flex items-center justify-center font-newsreader font-semibold text-[14px] shrink-0">
                                {getInitials(ownerName)}
                              </div>
                              <div>
                                <p className="font-semibold text-[#191c1b] group-hover:text-[#4f604f] transition-colors">
                                  {ownerName}
                                </p>
                                {ownerEmail && (
                                  <p className="text-xs text-[#747872] mt-0.5">
                                    {ownerEmail}
                                  </p>
                                )}
                              </div>
                            </div>
                          </td>

                          {/* Hotel Name */}
                          <td className="py-4 px-6">
                            <p className="font-medium text-[#191c1b]">
                              {hotelName}
                            </p>
                            <p className="text-xs text-[#747872] mt-0.5">
                              {row.city || row.address ? `${row.city || row.address}` : "Hotel Partner"}
                            </p>
                          </td>

                          {/* Date Applied */}
                          <td className="py-4 px-6 text-[#434842]">
                            {row.created_at
                              ? new Date(row.created_at).toLocaleDateString("en-US", {
                                  month: "short",
                                  day: "numeric",
                                  year: "numeric",
                                })
                              : "-"}
                          </td>

                          {/* Status */}
                          <td className="py-4 px-6">
                            {isApproved ? (
                              <span className="inline-flex items-center px-3 py-1 rounded-full bg-[#d1eac9] text-[#0c200c] text-[11px] font-semibold tracking-[0.05em] uppercase">
                                Approved
                              </span>
                            ) : isRejected ? (
                              <span className="inline-flex items-center px-3 py-1 rounded-full bg-[#ffdad6] text-[#93000a] text-[11px] font-semibold tracking-[0.05em] uppercase">
                                Rejected
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-3 py-1 rounded-full bg-[#DED3C7] text-[#2F3231] text-[11px] font-semibold tracking-[0.05em] uppercase">
                                Pending
                              </span>
                            )}
                          </td>

                          {/* Action */}
                          <td
                            className="py-4 px-6 text-right whitespace-nowrap"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <div className="flex justify-end items-center gap-2">
                              <button
                                onClick={() => {
                                  setSelectedPartner(row);
                                  setIsReviewModalOpen(true);
                                }}
                                className="px-3.5 py-1.5 border border-[#768875] text-[#768875] rounded-lg font-hanken text-[13px] font-semibold hover:bg-[#768875] hover:text-white transition-all active:scale-95 shadow-sm"
                              >
                                View Detail
                              </button>

                              {isPending && (
                                <>
                                  <button
                                    onClick={() => handleApprove(row.id)}
                                    title="Approve Application"
                                    className="px-3 py-1.5 bg-[#768875] text-white rounded-lg font-hanken text-[12.5px] font-semibold hover:bg-[#657764] transition-all active:scale-95 shadow-sm"
                                  >
                                    Approve
                                  </button>
                                  <button
                                    onClick={() => openRejectModal(row.id)}
                                    title="Reject Application"
                                    className="px-3 py-1.5 border border-[#ba1a1a] text-[#ba1a1a] rounded-lg font-hanken text-[12.5px] font-semibold hover:bg-[#ffdad6]/40 transition-all active:scale-95"
                                  >
                                    Reject
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td
                        colSpan="5"
                        className="py-12 text-center text-[#747872] font-hanken text-[14px]"
                      >
                        No partner applications found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            <div className="bg-[#F9F6F1] border-t border-[#E5E0D8] px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-body-sm text-[#747872] font-hanken">
              <span className="text-[13px]">
                Showing{" "}
                {totalItems > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0}{" "}
                to {Math.min(currentPage * itemsPerPage, totalItems)} of{" "}
                {totalItems} applications
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1 border border-[#E5E0D8] rounded-md bg-white hover:bg-[#F9F6F1] transition-colors disabled:opacity-40 disabled:cursor-not-allowed text-[13px] font-medium text-[#434842]"
                >
                  Prev
                </button>

                {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                  (pageNum) => (
                    <button
                      key={pageNum}
                      onClick={() => setCurrentPage(pageNum)}
                      className={`px-3 py-1 border rounded-md text-[13px] font-medium transition-colors ${
                        currentPage === pageNum
                          ? "bg-[#768875] text-white border-[#768875]"
                          : "bg-white border-[#E5E0D8] text-[#434842] hover:bg-[#F9F6F1]"
                      }`}
                    >
                      {pageNum}
                    </button>
                  )
                )}

                <button
                  onClick={() =>
                    setCurrentPage((p) => Math.min(p + 1, totalPages))
                  }
                  disabled={currentPage === totalPages || totalPages === 0}
                  className="px-3 py-1 border border-[#E5E0D8] rounded-md bg-white hover:bg-[#F9F6F1] transition-colors disabled:opacity-40 disabled:cursor-not-allowed text-[13px] font-medium text-[#434842]"
                >
                  Next
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Review Application Modal / Detail Panel */}
      {isReviewModalOpen && selectedPartner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop Blur */}
          <div
            className="fixed inset-0 bg-[#2e3130]/40 backdrop-blur-sm transition-opacity"
            onClick={() => setIsReviewModalOpen(false)}
          ></div>

          {/* Modal Container */}
          <div className="relative bg-white rounded-xl shadow-[0_12px_40px_rgba(47,50,49,0.12)] border border-[#E5E0D8] max-w-3xl w-full z-10 font-hanken overflow-hidden animate-fadeIn">
            {/* Modal Header */}
            <div className="p-6 border-b border-[#E5E0D8] flex justify-between items-center bg-[#F9F6F1]">
              <div>
                <h3 className="font-newsreader text-[22px] font-semibold text-[#191c1b] font-['Newsreader',serif]">
                  Review Application: {selectedPartner.hotel_name || "Partner Application"}
                </h3>
                <p className="font-hanken text-[12px] font-semibold tracking-[0.05em] text-[#747872] mt-0.5 uppercase">
                  App ID: #HHL-{String(selectedPartner.id).padStart(4, "0")} • Status:{" "}
                  <span
                    className={
                      (selectedPartner.status || "").toLowerCase() === "approved"
                        ? "text-[#4f604f]"
                        : (selectedPartner.status || "").toLowerCase() === "rejected"
                        ? "text-[#ba1a1a]"
                        : "text-[#DED3C7]"
                    }
                  >
                    {selectedPartner.status || "Pending"}
                  </span>
                </p>
              </div>
              <button
                onClick={() => setIsReviewModalOpen(false)}
                className="text-[#747872] hover:text-[#191c1b] p-2 rounded-full hover:bg-white/60 transition-colors"
              >
                <span className="material-symbols-outlined text-[22px]">close</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Column 1: Owner & Hotel Info */}
              <div className="flex flex-col gap-6">
                <div>
                  <h4 className="font-hanken text-[11px] font-semibold text-[#434842] uppercase tracking-[0.05em] mb-3 border-b border-[#E5E0D8] pb-2">
                    Owner Information
                  </h4>
                  <div className="grid grid-cols-2 gap-y-3.5 text-[13.5px]">
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">
                        Full Name
                      </p>
                      <p className="font-medium text-[#191c1b] mt-0.5">
                        {selectedPartner.applicant_name || selectedPartner.user?.name || "-"}
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">
                        Phone
                      </p>
                      <p className="font-medium text-[#191c1b] mt-0.5">
                        {selectedPartner.phone || selectedPartner.user?.phone || "-"}
                      </p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">
                        Email Address
                      </p>
                      <p className="font-medium text-[#191c1b] mt-0.5">
                        {selectedPartner.email || selectedPartner.user?.email || "-"}
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-hanken text-[11px] font-semibold text-[#434842] uppercase tracking-[0.05em] mb-3 border-b border-[#E5E0D8] pb-2">
                    Hotel Information
                  </h4>
                  <div className="grid grid-cols-2 gap-y-3.5 text-[13.5px]">
                    <div className="col-span-2">
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">
                        Property Name
                      </p>
                      <p className="font-medium text-[#191c1b] mt-0.5">
                        {selectedPartner.hotel_name || "-"}
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">
                        Property Type
                      </p>
                      <p className="font-medium text-[#191c1b] mt-0.5">
                        {selectedPartner.property_type || "Not specified"}
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">
                        Year Built
                      </p>
                      <p className="font-medium text-[#191c1b] mt-0.5">
                        {selectedPartner.year_built || "Not specified"}
                      </p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">
                        Address &amp; Location
                      </p>
                      <p className="font-medium text-[#191c1b] mt-0.5">
                        {selectedPartner.address || selectedPartner.city || "-"}
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">Stars (Partner Claim)</p>
                      <p className="font-medium text-[#191c1b] mt-0.5">{selectedPartner.requested_star_rating ? `★ ${selectedPartner.requested_star_rating}` : "Not Certified"}</p>
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-[#747872]">
                        Application Date
                      </p>
                      <p className="font-medium text-[#191c1b] mt-0.5">
                        {selectedPartner.created_at
                          ? new Date(selectedPartner.created_at).toLocaleDateString("id-ID")
                          : "-"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Column 2: Documents Preview & Actions */}
              <div className="flex flex-col gap-6 justify-between">
                <div>
                  <h4 className="font-hanken text-[11px] font-semibold text-[#434842] uppercase tracking-[0.05em] mb-3 border-b border-[#E5E0D8] pb-2">
                    Document Verification
                  </h4>

                  <div className="flex flex-col gap-3">
                    {(() => {
                      const docs = Array.isArray(selectedPartner.documents)
                        ? selectedPartner.documents
                        : [];
                      const legacyUrl = selectedPartner.document_url || selectedPartner.document
                        ? getStorageUrl(selectedPartner.document_url || selectedPartner.document)
                        : null;
                      const list = [];
                      docs.forEach((d, i) => {
                        const fallback = getStorageUrl(d.file_path || d.filePath || d.path || d.url);
                        list.push({ id: d.id, fallback, label: getDocLabel(d.document_type || d.type || `Document ${i + 1}`), icon: getDocIcon(d.document_type || d.type) });
                      });

                      if (!list.length) {
                        if (!legacyUrl) {
                          return (
                            <div className="border border-dashed border-[#E5E0D8] rounded-lg p-6 text-center text-[#747872] text-[13px]">
                              No digital document attachments for this application.
                            </div>
                          );
                        }
                        return (
                          <div className="border border-[#E5E0D8] rounded-lg p-3.5 flex items-center gap-3.5 bg-[#F9F6F1]/40">
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-[#191c1b] text-[13.5px]">Partner Legality Document</p>
                              <button onClick={() => window.open(legacyUrl, "_blank", "noopener,noreferrer")} className="text-xs text-[#768875] hover:underline font-medium mt-0.5">
                                Open Document File &rarr;
                              </button>
                            </div>
                          </div>
                        );
                      }

                      return list.map((item) => (
                        <div
                          key={item.id || item.label}
                          className="border border-[#E5E0D8] rounded-lg p-3.5 flex items-center gap-3.5 hover:border-[#768875] transition-colors bg-[#F9F6F1]/40 group"
                        >
                          <div className="w-11 h-11 bg-[#edeeec] rounded-lg flex items-center justify-center text-[#747872] group-hover:text-[#4f604f] transition-colors shrink-0">
                            <span className="material-symbols-outlined text-[24px]">
                              {item.icon}
                            </span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-[#191c1b] text-[13.5px] truncate">
                              {item.label}
                            </p>
                            <button
                              onClick={() => openPartnerDocument(selectedPartner.id, item.id, item.fallback)}
                              className="text-xs text-[#768875] hover:underline font-medium mt-0.5 inline-block"
                            >
                              Open Document File &rarr;
                            </button>
                          </div>
                          <button
                            onClick={() => openPartnerDocument(selectedPartner.id, item.id, item.fallback)}
                            className="text-[#747872] group-hover:text-[#768875] p-1.5"
                            title="Preview / Download"
                          >
                            <span className="material-symbols-outlined text-[20px]">
                              visibility
                            </span>
                          </button>
                        </div>
                      ));
                    })()}
                  </div>
                </div>

                {/* Bottom Decision Actions */}
                <div className="pt-6 border-t border-[#E5E0D8] flex gap-3">
                  {(selectedPartner.status || "").toLowerCase() === "pending" ? (
                    <>
                      <button
                        onClick={() => openRejectModal(selectedPartner.id)}
                        className="flex-1 py-2.5 border border-[#ba1a1a] text-[#ba1a1a] rounded-lg font-hanken text-[13.5px] font-semibold hover:bg-[#ffdad6]/40 transition-colors shadow-sm active:scale-95"
                      >
                        Reject
                      </button>
                      <button
                        onClick={() => handleApprove(selectedPartner.id)}
                        className="flex-1 py-2.5 bg-[#768875] text-white rounded-lg font-hanken text-[13.5px] font-semibold hover:bg-[#657764] transition-colors shadow-sm active:scale-95"
                      >
                        Approve
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => setIsReviewModalOpen(false)}
                      className="w-full py-2.5 border border-[#E5E0D8] text-[#434842] hover:bg-[#F9F6F1] rounded-lg font-hanken text-[13.5px] font-semibold transition-colors"
                    >
                      Close
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Reject Reason Modal */}
      {isRejectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-[#2e3130]/40 backdrop-blur-sm"
            onClick={() => setIsRejectModalOpen(false)}
          ></div>

          <div className="relative bg-white rounded-xl shadow-[0_12px_40px_rgba(47,50,49,0.12)] border border-[#E5E0D8] p-6 max-w-md w-full z-10 font-hanken animate-fadeIn">
            <div className="flex justify-between items-center mb-4 pb-3 border-b border-[#E5E0D8]">
              <h3 className="font-newsreader text-[20px] font-semibold text-[#ba1a1a]">
                Reject Partner Application
              </h3>
              <button
                onClick={() => setIsRejectModalOpen(false)}
                className="text-[#747872] hover:text-[#191c1b]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <form onSubmit={handleConfirmReject} className="space-y-4">
              <div>
                <label className="block font-hanken text-[11px] font-semibold text-[#747872] uppercase tracking-[0.05em] mb-1.5">
                  Rejection Reason (Required)
                </label>
                <textarea
                  rows="4"
                  required
                  placeholder="e.g. Invalid or incomplete licensing documents..."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  className="w-full p-3 bg-white border border-[#E5E0D8] rounded-lg font-hanken text-[13.5px] text-[#191c1b] focus:outline-none focus:border-[#ba1a1a] focus:ring-2 focus:ring-[#ba1a1a]/20 transition-all resize-none"
                ></textarea>
              </div>

              <div className="flex justify-end items-center gap-3 pt-3 border-t border-[#E5E0D8]">
                <button
                  type="button"
                  onClick={() => setIsRejectModalOpen(false)}
                  className="px-4 py-2 border border-[#E5E0D8] rounded-lg font-hanken text-[13px] font-semibold text-[#434842] hover:bg-[#F9F6F1] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={rejectLoading}
                  className={`px-5 py-2 bg-[#ba1a1a] text-white rounded-lg font-hanken text-[13px] font-semibold hover:bg-[#93000a] transition-all shadow-sm ${
                    rejectLoading ? "opacity-60 cursor-not-allowed" : "active:scale-95"
                  }`}
                >
                  {rejectLoading ? "Saving..." : "Confirm Rejection"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {pendingApprove && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-[#2e3130]/40 backdrop-blur-sm" onClick={() => !isApproving && setPendingApprove(null)}></div>
          <div className="relative bg-white rounded-xl border border-[#E5E0D8] p-6 max-w-md w-full z-10 font-hanken">
            <h3 className="font-newsreader text-lg font-semibold mb-1">Approve Partner + Star Rating</h3>
            {(() => { const p = partners.find((x) => x.id === pendingApprove); return p?.requested_star_rating ? <p className="text-xs text-[#747872] mb-3">Partner claim: ★ {p.requested_star_rating} — correct below if needed.</p> : null; })()}
            <div className="space-y-3">
              <select value={approveStar} onChange={(e) => setApproveStar(e.target.value)} className="w-full px-3 py-2 border border-[#E5E0D8] rounded-lg text-sm">
                <option value="">Unverified</option>{[1,2,3,4,5].map(n => <option key={n} value={String(n)}>{n} Stars</option>)}
              </select>
              <textarea value={approveStarReason} onChange={(e) => setApproveStarReason(e.target.value)} placeholder="Correction reason (optional)" rows={2} className="w-full px-3 py-2 border border-[#E5E0D8] rounded-lg text-sm resize-none" />
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <button onClick={() => setPendingApprove(null)} disabled={isApproving} className="px-4 py-2 border border-[#E5E0D8] rounded-lg text-sm">Cancel</button>
              <button onClick={performApprove} disabled={isApproving} className="px-4 py-2 bg-[#4F6F52] text-white rounded-lg text-sm font-semibold disabled:opacity-50">{isApproving ? "..." : "Yes, Approve"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PartnerApproval;
